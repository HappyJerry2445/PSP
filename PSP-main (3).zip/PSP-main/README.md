# PSP
This is project from students of ITI Renato Elia 5F,5E


Necessary python libraries:
sqlmodel
fastapi
uvicorn
jinja2
python-codicefiscale
httptools
pymysql
